LogixaLab — Hostinger upload checklist

DO NOT rely on hPanel zip extract alone — it often breaks folders.

Recommended:
1. Upload logixalab-hostinger.zip to public_html.
2. Upload deploy-extract.php and DEPLOY-KEY.txt to public_html.
3. Open: https://yourdomain.com/deploy-extract.php?key=KEY_FROM_DEPLOY-KEY.txt
4. Confirm [ok] for nxt/static/chunks and images/background.webp.
5. Delete deploy-extract.php, DEPLOY-KEY.txt, and the zip.
6. Hard-refresh the browser (Ctrl+Shift+R).

See deploy/HOSTINGER.md for full instructions.